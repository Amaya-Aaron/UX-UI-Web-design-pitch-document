// Lista de imágenes de fondo para el menú
const menuBackgrounds = [
    'https://lh3.googleusercontent.com/p/AF1QipPme1b0pH1i-jW239rb_RIVvPtD8RPCnHlX573E=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipMbLKC8Gpm_Df7woKLwZ3qUtqJKLlGcoDKlfke3=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipPVgbNMyFXPyLaIzRDwhR-ac1O1L5AzSt33UWbQ=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipNy7GWHQ4h-jMLK-pVfYZ5CuwZD4J1HvG-v9lj9=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipOGA5fx-3YePi5Ct38-SP-4Le_YjdnRc8h8sUQX=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipOs3F0XiFD9WidN2n-ZKln_BnoSZgDfyznNNrbo=s1360-w1360-h1020',
    'https://lh3.googleusercontent.com/p/AF1QipMkV9UlO5Dff-Os6-zgcD4RxOBqjKrKEO6o0UjA=s1360-w1360-h1020'    
  ];
  
  // Función para cambiar aleatoriamente el fondo del menú
  function changeMenuBackground() {
    const randomIndex = Math.floor(Math.random() * menuBackgrounds.length);
    const randomImage = menuBackgrounds[randomIndex];
    const menuSection = document.getElementById('menu');
    menuSection.style.backgroundImage = `url(${randomImage})`;
  }
  
  // Cambiar el fondo del menú cada 5 segundos
  setInterval(changeMenuBackground, 2000);
  
  